{-# LANGUAGE FlexibleInstances #-}
module Main where

import Test.QuickCheck
import Data.List(intercalate)

instance (Enum a, Bounded a, Show  a) => Show (a -> Bool) where
  show f = intercalate "\n" (map (\x -> "f " ++ show x ++ " = " ++ show (f x)) [minBound .. maxBound])

propFilterNoLonger = undefined
propFilterAllSatisfy = undefined
propFilterAllElements = undefined
propFilterCorrect = undefined


propMapLength = undefined

propPermsCorrect = undefined
propPermsLength = undefined
propPermsArePerms = undefined


data Tree a = Branch a (Tree a) (Tree a) | Leaf
            deriving (Show)

insertTree :: Ord a => a -> Tree a -> Tree a
insertTree e Leaf = Branch e Leaf Leaf
insertTree e (Branch x li re)
  | e <= x = Branch x (insertTree e li) re
  | e >  x = Branch x li (insertTree e re)

genBSTI :: Gen (Tree Int)
genBSTI = undefined

isSearchTree :: Ord a => Tree a -> Bool
isSearchTree = undefined

propInsertIsTree :: Ord a => Tree a -> a -> Bool
propInsertIsTree = undefined

propInsertIsTreeWrong :: Ord a => Tree a -> a -> Bool
propInsertIsTreeWrong = undefined

runTests :: IO ()
runTests = do
  putStrLn "\nExercise 14.1"
  quickCheck (propFilterNoLonger      :: (Bool -> Bool) -> [Bool] -> Bool)
  quickCheck (propFilterAllSatisfy    :: (Bool -> Bool) -> [Bool] -> Bool)
  quickCheck (propFilterAllElements   :: (Bool -> Bool) -> [Bool] -> Bool)
  quickCheck (propFilterCorrect       :: (Bool -> Bool) -> [Bool] -> Bool)
  putStrLn "\nExercise 14.2"
  quickCheck (propMapLength :: (Bool -> Bool) -> [Bool] -> Bool)
  putStrLn "\nExercise 14.3"
  quickCheck $ once (propPermsLength   :: [Int] -> Bool)
  quickCheck $ once (propPermsArePerms :: [Int] -> Bool)
  quickCheck $ once (propPermsCorrect  :: [Int] -> Bool)
  putStrLn "\nExercise 14.5"
  quickCheck (forAll genBSTI isSearchTree)    -- Use forAll to use custom generator
  quickCheck (forAll genBSTI propInsertIsTree)
  quickCheck (forAll genBSTI propInsertIsTreeWrong)

main = runTests
